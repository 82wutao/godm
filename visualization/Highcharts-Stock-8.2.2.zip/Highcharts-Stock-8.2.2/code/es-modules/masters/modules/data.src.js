/**
 * @license Highcharts JS v8.2.2 (2020-10-22)
 * @module highcharts/modules/data
 * @requires highcharts
 *
 * Data module
 *
 * (c) 2012-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/Data.js';
