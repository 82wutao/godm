/**
 * @license Highstock JS v8.2.2 (2020-10-22)
 * @module highcharts/indicators/indicators
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Slow Stochastic series type for Highstock
 *
 * (c) 2010-2019 Pawel Fus
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Stock/Indicators/SlowStochasticIndicator.js';
