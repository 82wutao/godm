/**
 * @license Highcharts Gantt JS v8.2.2 (2020-10-22)
 * @module highcharts/modules/pathfinder
 * @requires highcharts
 *
 * Pathfinder
 *
 * (c) 2016-2019 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Gantt/Pathfinder.js';
